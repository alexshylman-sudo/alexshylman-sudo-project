"""
Pinterest API Integration
"""
from .client import PinterestClient

__all__ = ['PinterestClient']
