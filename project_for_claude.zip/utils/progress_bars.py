"""
Модуль для генерации красивых прогресс-баров
"""

def generate_gradient_progress_bar(progress, total_blocks=12, title="ПРОГРЕСС"):
    """
    Генерирует красивый прогресс-бар с градиентом от красного к зеленому
    Использует 12 кругов вместо квадратов
    
    Args:
        progress: Прогресс в процентах (0-100)
        total_blocks: Количество кругов в прогресс-баре (по умолчанию 12)
        title: Заголовок прогресс-бара
    
    Returns:
        str: Отформатированный прогресс-бар с градиентом из кругов
    """
    # Расчет количества заполненных кругов
    filled_blocks = int((progress / 100) * total_blocks)
    
    # Используем градиент из 4 цветов
    # 🔴 = красный (0-25%)
    # 🟠 = оранжевый (25-50%)
    # 🟡 = желтый (50-75%)
    # 🟢 = зеленый (75-100%)
    # ⚪ = белый (пустой)
    
    gradient_blocks = []
    for i in range(total_blocks):
        if i < filled_blocks:
            # Определяем цвет круга в зависимости от позиции (по 3 круга каждого цвета)
            if i < 3:  # Первые 3 круга - красные
                gradient_blocks.append("🔴")
            elif i < 6:  # 4-6 круги - оранжевые
                gradient_blocks.append("🟠")
            elif i < 9:  # 7-9 круги - желтые
                gradient_blocks.append("🟡")
            else:  # 10-12 круги - зеленые
                gradient_blocks.append("🟢")
        else:
            gradient_blocks.append("⚪")
    
    # Формируем строку БЕЗ пробелов - так Telegram не обрежет
    bar = "".join(gradient_blocks)
    
    return f"<b>{title}</b> {progress}%\n{bar}"


def generate_seo_score_bar(score):
    """
    Генерирует прогресс-бар для SEO оценки (0-100)
    Использует 12 кругов
    
    Args:
        score: SEO оценка (0-100)
    
    Returns:
        str: Отформатированный прогресс-бар с оценкой
    """
    filled_blocks = int((score / 100) * 12)
    
    gradient_blocks = []
    for i in range(12):
        if i < filled_blocks:
            block_score = ((i + 1) / 12) * 100
            
            if block_score <= 40:
                gradient_blocks.append("🔴")
            elif block_score <= 70:
                gradient_blocks.append("🟡")
            else:
                gradient_blocks.append("🟢")
        else:
            gradient_blocks.append("⚪")
    
    bar = "".join(gradient_blocks)  # БЕЗ пробелов
    
    # Определяем статус
    if score < 40:
        status_emoji = "🔴"
        status_text = "Плохо"
    elif score < 70:
        status_emoji = "🟡"
        status_text = "Средне"
    elif score < 85:
        status_emoji = "🟢"
        status_text = "Хорошо"
    else:
        status_emoji = "✅"
        status_text = "Отлично"
    
    return f"{bar}\n{status_emoji} *{score}/100* — _{status_text}_"