"""
Генерация ключевых фраз с помощью Claude AI
"""
import anthropic
from config import ANTHROPIC_API_KEY


# Инициализация клиента
client = None
if ANTHROPIC_API_KEY:
    try:
        client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    except Exception as e:
        print(f"⚠️ Ошибка инициализации Claude: {e}")


def generate_keywords(
    category_name,
    niche,
    target_audience,
    products_services,
    location,
    goals,
    quantity=50
):
    """
    Генерация ключевых фраз с помощью Claude AI
    
    Args:
        category_name: Название категории
        niche: Ниша/направление бизнеса
        target_audience: Целевая аудитория
        products_services: Товары/услуги
        location: Местоположение бизнеса
        goals: Цели продвижения
        quantity: Количество фраз (50, 100, 150, 200)
    
    Returns:
        dict: {
            'success': bool,
            'keywords': list,
            'error': str (если ошибка)
        }
    """
    if not ANTHROPIC_API_KEY or not client:
        return {
            'success': False,
            'keywords': [],
            'error': '⚠️ Claude API не настроен. Добавьте ANTHROPIC_API_KEY в .env'
        }
    
    # Профессиональный системный промпт (улучшенная версия 2.1)
    system_prompt = f"""Ты профессиональный SEO-специалист. Собираешь семантическое ядро по всем правилам.

КРИТИЧЕСКИ ВАЖНЫЕ ПРАВИЛА:

1. ГЕНЕРИРУЙ ТОЛЬКО РЕАЛЬНЫЕ ПОИСКОВЫЕ ЗАПРОСЫ
   - Люди реально ищут эти фразы в Яндекс/Google
   - Никакой отсебятины и фантазий!
   - Если товар "{products_services}" - пиши про него, а не про другие товары

2. СТРУКТУРА СЯ (СТРОГО СОБЛЮДАЙ ПРОПОРЦИИ):

   КОММЕРЧЕСКИЕ запросы (60% от всех):
   • Транзакционные с гео (30%) - ПРИОРИТЕТ:
     - [товар] купить в [город]
     - купить [товар] [город] 
     - [товар] [город] цена
     - где купить [товар] в [город]
     - [товар] недорого [город]
   
   • С характеристиками и помещениями (30%) - LONG-TAIL:
     - [товар] для [помещение] (спальня, гостиная, кухня, ванная, прихожая)
     - [товар] [размер] для [помещение]
     - [товар] [цвет] для [помещение]
     - [товар] [материал] [размер]
     - [товар] [характеристика] купить
   
   ИНФОРМАЦИОННЫЕ запросы (25% от всех):
   • Выбор и сравнение (10%):
     - как выбрать [товар]
     - какой [товар] лучше
     - [товар] или [аналог] что лучше
     - [товар] vs [аналог]
     - чем отличается [товар] от [аналог]
     - преимущества [товар] перед [аналог]
   
   • Установка и монтаж (7%):
     - как установить [товар]
     - как монтировать [товар]
     - установка [товар] своими руками
     - монтаж [товар] инструкция
   
   • Уход и эксплуатация (5%):
     - как ухаживать за [товар]
     - чем мыть [товар]
     - как чистить [товар]
     - срок службы [товар]
     - [товар] отзывы владельцев
   
   • Базовые вопросы (3%):
     - что такое [товар]
     - зачем нужен [товар]
     - [товар] плюсы и минусы
   
   НАВИГАЦИОННЫЕ запросы (15% от всех):
   • Категории и товары:
     - [категория товара]
     - [подкатегория]
     - [конкретный товар]
     - [бренд] [товар]

3. ЧАСТОТНОСТЬ И КОНКРЕТНОСТЬ:
   • ВЧ (1-2 слова): 5% — общие категории
   • СЧ (2-4 слова): 35% — основа ядра
   • НЧ (4-7 слов): 60% — конкретные long-tail МАКСИМАЛЬНО КОНКРЕТНЫЕ

4. ОБЯЗАТЕЛЬНЫЕ ТИПЫ ЗАПРОСОВ:
   ✅ Long-tail по помещениям: "[товар] для спальни 3х4 метра"
   ✅ Сравнительные: "[товар] или [аналог]", "[товар] vs [аналог]"
   ✅ По уходу: "как ухаживать за [товар]", "чем мыть [товар]"
   ✅ С гео + купить: "купить [товар] в москве", "[товар] москва цена"

5. ЗАПРЕЩЕНО ГЕНЕРИРОВАТЬ:
   ❌ Мусорные запросы не по теме
   ❌ Запросы с "климат", погодой (если не тема)
   ❌ Экзотические материалы которые НЕ продаются
   ❌ Фантазийные комбинации
   ❌ Запросы которые никто не ищет
   ❌ Общие фразы без конкретики

6. ФОРМАТ ВЫВОДА:
   - Каждая фраза на отдельной строке
   - БЕЗ нумерации, БЕЗ маркеров, БЕЗ пояснений
   - Только чистые ключевые фразы
   - РОВНО {quantity} фраз"""
    
    # Пользовательский промпт (улучшенный с long-tail и сравнениями)
    user_prompt = f"""Сгенерируй семантическое ядро из РОВНО {quantity} ключевых фраз.

══════════════════════════════════════
ДАННЫЕ О БИЗНЕСЕ:
══════════════════════════════════════

🏢 Товары/услуги: {products_services}
📂 Тип бизнеса: {niche}
👥 Целевая аудитория: {target_audience}
📍 География: {location}
🎯 Цель: {goals}

══════════════════════════════════════
ОБЯЗАТЕЛЬНАЯ СТРУКТУРА ЯДРА:
══════════════════════════════════════

1️⃣ КОММЕРЧЕСКИЕ ЗАПРОСЫ (~{int(quantity * 0.6)} шт):

A) Транзакционные с ГЕО (~{int(quantity * 0.30)} шт) - ПРИОРИТЕТ:
✅ ОБЯЗАТЕЛЬНО включи эти типы:
- {products_services} купить {location.split(',')[0] if location else 'москва'}
- купить {products_services} в {location.split(',')[0] if location else 'москве'}
- {products_services} {location.split(',')[0] if location else 'москва'} цена
- где купить {products_services} {location.split(',')[0] if location else 'москва'}
- {products_services} недорого {location.split(',')[0] if location else 'москва'}
- {products_services} с доставкой {location.split(',')[0] if location else 'москва'}
- заказать {products_services} {location.split(',')[0] if location else 'москва'}

B) LONG-TAIL по помещениям (~{int(quantity * 0.30)} шт):
✅ МАКСИМАЛЬНО КОНКРЕТНЫЕ запросы:
- {products_services} для спальни
- {products_services} для гостиной 
- {products_services} для кухни
- {products_services} для ванной
- {products_services} для прихожей
- {products_services} для детской комнаты
- {products_services} [размер] для [помещение]
- {products_services} [цвет] для [помещение]
- {products_services} [характеристика] купить

2️⃣ ИНФОРМАЦИОННЫЕ ЗАПРОСЫ (~{int(quantity * 0.25)} шт):

A) СРАВНИТЕЛЬНЫЕ (~{int(quantity * 0.10)} шт) - ОБЯЗАТЕЛЬНО:
✅ Включи популярные сравнения:
- {products_services} или [популярный аналог] что лучше
- {products_services} vs [аналог]
- чем отличается {products_services} от [аналог]
- какой {products_services} лучше выбрать
- преимущества {products_services} перед [аналог]
- {products_services} [материал] или [материал]

B) Установка/монтаж (~{int(quantity * 0.07)} шт):
- как установить {products_services}
- как монтировать {products_services}
- установка {products_services} своими руками
- монтаж {products_services} инструкция
- {products_services} установка цена

C) УХОД И ЭКСПЛУАТАЦИЯ (~{int(quantity * 0.05)} шт) - ОБЯЗАТЕЛЬНО:
✅ Важные практические вопросы:
- как ухаживать за {products_services}
- чем мыть {products_services}
- как чистить {products_services}
- срок службы {products_services}
- {products_services} отзывы владельцев
- можно ли мыть {products_services}

D) Базовые (~{int(quantity * 0.03)} шт):
- что такое {products_services}
- зачем нужен {products_services}
- {products_services} плюсы и минусы

3️⃣ НАВИГАЦИОННЫЕ ЗАПРОСЫ (~{int(quantity * 0.15)} шт):
- [категория]
- [подкатегория]
- [конкретный товар]
- [бренд] {products_services}

══════════════════════════════════════
⚠️ КРИТИЧЕСКИ ВАЖНО:
══════════════════════════════════════

🎯 ПРИОРИТЕТЫ (в таком порядке):
1. Фразы "купить" + гео ({location}) - для быстрой конверсии
2. Long-tail по помещениям (спальня, кухня, ванная...)
3. Сравнительные запросы ([товар] или [аналог])
4. Запросы по уходу (как мыть, чистить, ухаживать)

✅ ОБЯЗАТЕЛЬНО включи:
• Минимум 20% запросов должны содержать название помещения
• Минимум 10% сравнительных запросов ("или", "vs", "чем отличается")
• Минимум 5% про уход и эксплуатацию
• 60% фраз должны быть LONG-TAIL (4-7 слов)

❌ НЕ генерируй:
• Общие фразы без конкретики
• Мусор про климат/погоду/экзотику
• Товары которые НЕ продаёт бизнес

Начинай сразу с ключевых фраз. Выдай РОВНО {quantity} строк:"""
    
    try:
        # Запрос к Claude
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=12000,  # Увеличено для генерации до 200 фраз
            system=system_prompt,
            messages=[
                {
                    "role": "user",
                    "content": user_prompt
                }
            ]
        )
        
        # Логируем затраты
        try:
            if hasattr(response, 'usage') and response.usage:
                from utils.api_cost_tracker import log_claude_usage
                log_claude_usage(
                    user_id=0,
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                    model="claude-sonnet-4-20250514",
                    operation_type='keywords_generation'
                )
        except Exception as e:
            print(f"⚠️ Ошибка логирования затрат: {e}")
        
        # Извлекаем текст ответа
        if response and response.content:
            text = response.content[0].text
            
            # Разбиваем на строки и очищаем
            lines = text.strip().split('\n')
            keywords = []
            
            for line in lines:
                # Убираем пустые строки
                line = line.strip()
                if not line:
                    continue
                
                # Убираем номера и маркеры
                line = line.lstrip('0123456789.-•*> ')
                line = line.strip()
                
                # Пропускаем слишком короткие
                if len(line) < 3:
                    continue
                
                # Пропускаем строки-комментарии
                if line.startswith('#') or line.startswith('//'):
                    continue
                
                keywords.append(line)
            
            # Ограничиваем количество до запрошенного
            keywords = keywords[:quantity]
            
            return {
                'success': True,
                'keywords': keywords,
                'total': len(keywords)
            }
        else:
            return {
                'success': False,
                'keywords': [],
                'error': 'Claude вернул пустой ответ'
            }
            
    except Exception as e:
        error_msg = str(e)
        if len(error_msg) > 200:
            error_msg = error_msg[:200] + "..."
        
        return {
            'success': False,
            'keywords': [],
            'error': f'Ошибка Claude AI: {error_msg}'
        }


def generate_keywords_fallback(category_name, niche, quantity=50):
    """
    Заглушка для генерации ключевых фраз если Claude недоступен
    Генерирует шаблонные фразы на основе категории и ниши
    """
    templates = [
        "{niche} купить",
        "{niche} цена",
        "{niche} заказать",
        "где купить {niche}",
        "{niche} отзывы",
        "{niche} недорого",
        "{niche} с доставкой",
        "лучший {niche}",
        "{niche} для дома",
        "{niche} для офиса",
        "как выбрать {niche}",
        "{niche} качественный",
        "{niche} дешево",
        "{niche} оптом",
        "{niche} в розницу",
        "профессиональный {niche}",
        "{niche} топ",
        "{niche} рейтинг",
        "{niche} сравнение",
        "{niche} характеристики",
    ]
    
    keywords = []
    niche_lower = niche.lower()
    
    # Генерируем фразы из шаблонов
    for template in templates:
        keyword = template.format(niche=niche_lower)
        keywords.append(keyword)
        
        if len(keywords) >= quantity:
            break
    
    # Добавляем вариации если нужно больше
    if len(keywords) < quantity:
        variations = [
            f"{niche_lower} интернет магазин",
            f"{niche_lower} официальный сайт",
            f"{niche_lower} каталог",
            f"{niche_lower} скидки",
            f"{niche_lower} акции",
            f"{niche_lower} распродажа",
            f"{niche_lower} новинки",
            f"{niche_lower} популярные",
            f"{niche_lower} рекомендации",
            f"{niche_lower} советы",
        ]
        keywords.extend(variations)
    
    return {
        'success': True,
        'keywords': keywords[:quantity],
        'total': min(len(keywords), quantity),
        'fallback': True
    }


print("✅ ai/keywords_generator.py загружен")
