# 🚀 VK OAuth - Полная инструкция по развертыванию

## ✅ Что уже сделано:

1. **VK ID приложение создано:**
   - App ID: `54433963`
   - App Secret: добавлен в Render.com
   - Redirect URI: `https://alexshylman-sudo-project.onrender.com/vk_callback`

2. **Код готов:**
   - VK OAuth handlers
   - Webhook сервер (Flask)
   - Telegram handlers
   - Автоматическое сохранение в БД

---

## 📋 Шаги для запуска:

### Шаг 1: Обновить код на сервере

Распакуй архив `VK_OAUTH_FINAL.zip` и загрузи все файлы на сервер.

**Важные файлы:**
```
handlers/vk_integration/
  ├── __init__.py
  ├── vk_config.py
  ├── vk_oauth.py
  └── vk_telegram_handler.py

vk_webhook.py
start.sh
```

---

### Шаг 2: Проверить переменные окружения на Render.com

Зайди в **Dashboard → Environment** и проверь:

```env
VK_APP_ID=54433963
VK_APP_SECRET=76cdf... (твой секретный ключ)
PORT=10000
```

---

### Шаг 3: Добавить импорт в handlers/__init__.py

Открой файл `handlers/__init__.py` и **добавь в конец**:

```python
# VK Integration (OAuth)
try:
    from handlers.vk_integration import *
    print("✅ VK Integration загружен")
except Exception as e:
    print(f"⚠️ VK Integration не загружен: {e}")
```

---

### Шаг 4: Настроить запуск на Render.com

#### Вариант A: Один Web Service (рекомендуется)

В настройках проекта на Render.com:

**Build Command:**
```bash
pip install -r requirements.txt
chmod +x start.sh
```

**Start Command:**
```bash
./start.sh
```

Или если не работает:
```bash
python vk_webhook.py & python main.py
```

#### Вариант B: Два отдельных сервиса

Создай 2 Web Services:

**Сервис 1: Telegram Bot**
- Start Command: `python main.py`

**Сервис 2: VK Webhook**
- Start Command: `python vk_webhook.py`
- Environment: те же переменные

---

### Шаг 5: Проверить requirements.txt

Убедись что есть Flask:

```txt
flask>=2.3.0
```

Если нет - добавь.

---

### Шаг 6: Проверить работу

#### Проверка webhook:
```
https://alexshylman-sudo-project.onrender.com/health
```

Должно вернуть:
```json
{
  "status": "ok",
  "service": "vk_webhook"
}
```

#### Проверка в боте:

В боте должна появиться кнопка:
```
🔵 Подключить VK
```

или

```
🔵 VK Аккаунт
```

---

## 🎯 Как работает OAuth:

### Шаг 1: Пользователь нажимает "Подключить VK"

```
🔵 ПОДКЛЮЧЕНИЕ ВКОНТАКТЕ

Для подключения VK аккаунта нажмите кнопку ниже.

✅ Что это даст:
• Автоматическая публикация постов в VK
• Управление сообществом
• Получение статистики

🔒 Ваши данные в безопасности.

[🔵 Войти через VK]  [🔙 Назад]
```

### Шаг 2: Открывается VK

Пользователь авторизуется и разрешает доступ.

### Шаг 3: Redirect на webhook

VK перенаправляет на:
```
https://alexshylman-sudo-project.onrender.com/vk_callback?code=xxx&state=tg_123
```

### Шаг 4: Webhook обрабатывает

```
✅ VK Token получен:
   User ID: 123456789
   Email: user@example.com

✅ VK подключен для пользователя 123456789
   VK ID: 123456789
   VK Name: Александр Шульман
```

### Шаг 5: Уведомление в Telegram

```
✅ VK успешно подключен!

Теперь вы можете публиковать посты в ВКонтакте.
```

---

## 🐛 Возможные проблемы:

### "Connection refused" при обращении к webhook

**Причина:** Webhook сервер не запущен

**Решение:**
1. Проверь логи на Render.com
2. Убедись что запущен `vk_webhook.py`
3. Проверь порт (должен быть 10000 или из переменной PORT)

---

### "VK_APP_SECRET not set"

**Причина:** Не добавлена переменная окружения

**Решение:**
Добавь в Render.com Environment:
```
VK_APP_SECRET=твой_секретный_ключ
```

---

### "Redirect URI mismatch"

**Причина:** В VK ID указан неправильный Redirect URI

**Решение:**
Зайди в настройки VK ID приложения и проверь:
```
https://alexshylman-sudo-project.onrender.com/vk_callback
```

---

### Webhook не отвечает на /health

**Причина:** Flask не запустился или порт занят

**Решение:**
1. Проверь логи: есть ли ошибки импорта
2. Убедись что Flask установлен: `pip install flask`
3. Проверь что порт 10000 свободен

---

## 📊 Архитектура:

```
┌─────────────────┐
│  Telegram Bot   │
│   (main.py)     │
└────────┬────────┘
         │
         ├─ handlers/vk_integration/
         │  ├─ vk_telegram_handler.py  → Кнопки в боте
         │  ├─ vk_config.py            → Настройки OAuth
         │  └─ vk_oauth.py             → OAuth логика
         │
         └─ vk_webhook.py               → Flask сервер
                 │
                 ├─ GET /health         → Health check
                 ├─ GET /               → Info
                 └─ GET /vk_callback    → OAuth callback
                       │
                       ├─ Получает code от VK
                       ├─ Обменивает на token
                       ├─ Получает данные пользователя
                       ├─ Сохраняет в БД
                       └─ Отправляет уведомление в TG
```

---

## ✅ Checklist перед запуском:

- [ ] Код загружен на сервер
- [ ] `VK_APP_SECRET` добавлен в Environment
- [ ] `handlers/__init__.py` обновлен (добавлен импорт)
- [ ] `requirements.txt` содержит Flask
- [ ] Start Command настроен: `./start.sh` или `python vk_webhook.py & python main.py`
- [ ] VK ID приложение настроено с правильным Redirect URI
- [ ] Сервис перезапущен на Render.com

---

## 🎉 После запуска:

1. Проверь `/health` endpoint
2. Проверь логи на наличие ошибок
3. Попробуй подключить VK через бота
4. Проверь что данные сохранились в БД

**Готово к запуску!** 🚀

Если возникнут проблемы - присылай логи и разберемся!
