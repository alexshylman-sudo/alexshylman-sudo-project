# -*- coding: utf-8 -*-
"""
Модуль автоматической рассылки уведомлений
- Поздравления с регистрацией
- Напоминания о низком балансе
- Еженедельные новости
- Реактивация неактивных
"""
import logging
from datetime import datetime, timedelta
from loader import bot
from database.database import db

logger = logging.getLogger(__name__)


def send_welcome_notification(user_id, username=None):
    """
    Отправляет приветственное уведомление новому пользователю
    
    Args:
        user_id: Telegram ID пользователя
        username: Username пользователя (опционально)
    """
    try:
        welcome_text = f"""
🎉 <b>Поздравляем с регистрацией!</b>

Добро пожаловать в AI Bot Creator!

🎁 Вам начислено <b>1500 токенов</b> для старта

<b>Что вы можете делать:</b>
✅ Создавать AI-ботов для контента
✅ Генерировать статьи и изображения
✅ Публиковать в соцсети и на сайты
✅ Настраивать автопостинг

💡 <b>Совет:</b> Начните с создания первого проекта!
Нажмите /start чтобы начать

<i>Если возникнут вопросы - пишите в поддержку</i>
"""
        
        bot.send_message(
            user_id,
            welcome_text,
            parse_mode='HTML'
        )
        
        logger.info(f"✅ Приветственное сообщение отправлено пользователю {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка отправки приветствия пользователю {user_id}: {e}")
        return False


def send_low_balance_notification(user_id, current_balance):
    """
    Отправляет уведомление о низком балансе токенов
    
    Args:
        user_id: Telegram ID пользователя
        current_balance: Текущий баланс токенов
    """
    try:
        low_balance_text = f"""
⚠️ <b>Низкий баланс токенов</b>

Ваш текущий баланс: <b>{current_balance} токенов</b>

Скоро токены закончатся! 
Пополните баланс, чтобы продолжить использование бота.

<b>Способы пополнения:</b>
💳 Купить токены - /tariffs
🎁 Пригласить друзей - получить бонус
🏆 Выполнить задания

<i>Без токенов генерация контента будет недоступна</i>
"""
        
        bot.send_message(
            user_id,
            low_balance_text,
            parse_mode='HTML'
        )
        
        logger.info(f"✅ Уведомление о низком балансе отправлено пользователю {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка отправки уведомления о балансе пользователю {user_id}: {e}")
        return False


def send_weekly_news(user_id):
    """
    Отправляет еженедельную новостную рассылку
    
    Args:
        user_id: Telegram ID пользователя
    """
    try:
        news_text = f"""
📰 <b>Еженедельные новости</b>

<b>Что нового на этой неделе:</b>

🆕 Добавлена поддержка WordPress API
✨ Улучшена генерация статей с Claude Sonnet 4
🎨 Новые стили оформления для изображений
⚡ Ускорена публикация в соцсети

<b>Полезные советы:</b>
💡 Используйте длинные slug для лучшего SEO
📊 Проверяйте аналитику в профиле
🔧 Настройте автоматическое расписание

<i>Следующая рассылка через неделю</i>
"""
        
        bot.send_message(
            user_id,
            news_text,
            parse_mode='HTML'
        )
        
        logger.info(f"✅ Еженедельные новости отправлены пользователю {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка отправки новостей пользователю {user_id}: {e}")
        return False


def send_reactivation_notification(user_id, days_inactive):
    """
    Отправляет уведомление для реактивации неактивного пользователя
    
    Args:
        user_id: Telegram ID пользователя
        days_inactive: Количество дней неактивности
    """
    try:
        reactivation_text = f"""
😔 <b>Давно не виделись!</b>

Вы не заходили в бот уже <b>{days_inactive} дней</b>

<b>Мы скучаем!</b> 🥺

<b>Что нового появилось:</b>
🎁 Новые бонусные токены
🚀 Улучшенные алгоритмы генерации
📈 Расширенная аналитика
🎨 Больше стилей оформления

💝 <b>Специальное предложение для вас:</b>
Вернитесь в течение 7 дней и получите +200 бонусных токенов!

Нажмите /start чтобы продолжить
"""
        
        bot.send_message(
            user_id,
            reactivation_text,
            parse_mode='HTML'
        )
        
        logger.info(f"✅ Уведомление реактивации отправлено пользователю {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка отправки реактивации пользователю {user_id}: {e}")
        return False


def check_and_send_notifications():
    """
    Проверяет пользователей и отправляет нужные уведомления
    Запускается по расписанию (cron/scheduler)
    """
    try:
        logger.info("🔍 Запуск проверки уведомлений...")
        
        # 1. Проверяем пользователей с низким балансом (< 100 токенов)
        cursor = db.conn.cursor()
        cursor.execute("""
            SELECT id, balance, username
            FROM users
            WHERE balance < 100 AND balance > 0
        """)
        low_balance_users = cursor.fetchall()
        
        logger.info(f"Найдено пользователей с низким балансом: {len(low_balance_users)}")
        
        for user in low_balance_users:
            user_id, balance, username = user
            # Проверяем, не отправляли ли уже сегодня
            # (можно добавить таблицу отправленных уведомлений)
            send_low_balance_notification(user_id, balance)
        
        # 2. Проверяем неактивных пользователей (не заходили 7+ дней)
        week_ago = datetime.now() - timedelta(days=7)
        
        cursor.execute("""
            SELECT id, created_at, username
            FROM users
            WHERE created_at < %s
        """, (week_ago,))
        inactive_users = cursor.fetchall()
        
        logger.info(f"Найдено неактивных пользователей: {len(inactive_users)}")
        
        for user in inactive_users:
            user_id, created_at, username = user
            days_inactive = (datetime.now() - created_at).days
            
            # Отправляем реактивацию только раз в 30 дней
            if days_inactive >= 7 and days_inactive % 30 == 0:
                send_reactivation_notification(user_id, days_inactive)
        
        cursor.close()
        logger.info("✅ Проверка уведомлений завершена")
        
    except Exception as e:
        logger.error(f"❌ Ошибка проверки уведомлений: {e}")


# Регистрация обработчиков
def register_notification_handlers(bot_instance):
    """
    Регистрирует обработчики для автоматических уведомлений
    
    Args:
        bot_instance: Экземпляр бота
    """
    logger.info("✅ Модуль автоматических уведомлений загружен")


# Автозагрузка при импорте
register_notification_handlers(bot)

print("✅ handlers/auto_notifications.py загружен")
