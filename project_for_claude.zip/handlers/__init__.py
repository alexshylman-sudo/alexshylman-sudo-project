"""
Модуль обработчиков команд и сообщений бота

🔍 CALLBACK TRACKER - Система отслеживания кнопок
================================================

Callback Tracker автоматически отслеживает все нажатия кнопок и помогает найти
"мёртвые" кнопки, которые не работают.

📖 Подробное руководство: см. CALLBACK_TRACKER_GUIDE.md

ИСПОЛЬЗОВАНИЕ В ОБРАБОТЧИКАХ:
------------------------------

Вариант 1: Автоматическое отслеживание (рекомендуется)
-------------------------------------------------------
Просто пишите обработчики как обычно. Система автоматически
отловит необработанные кнопки:

    @bot.callback_query_handler(func=lambda call: call.data.startswith("my_button_"))
    def my_handler(call):
        # Ваш код
        pass

Вариант 2: С декоратором (для детального отслеживания)
-------------------------------------------------------
Используйте декоратор @track_callback для более подробных логов:

    from callback_tracker import track_callback
    
    @track_callback("project_buttons")  # Имя группы кнопок
    @bot.callback_query_handler(func=lambda call: call.data.startswith("open_project_"))
    def open_project_handler(call):
        # Ваш код
        pass

ЧТО ВЫ УВИДИТЕ В ЛОГАХ:
-----------------------

✅ Успешное нажатие:
    🔘 CALLBACK PRESSED: 'open_project_123' | User: 987654 (@username)
    ✅ CALLBACK SUCCESS: 'open_project_123' | Executed in 45.2ms

⚠️ Необработанная кнопка:
    ⚠️ UNHANDLED CALLBACK: 'some_button' | 🚨 НЕТ ОБРАБОТЧИКА!

❌ Ошибка в обработчике:
    ❌ CALLBACK ERROR: 'open_project_123' | File: handlers/projects.py:45
       Error: KeyError: 'project_id'

📊 При остановке бота (Ctrl+C) выводится полная статистика:
    - Сколько раз нажималась каждая кнопка
    - Какие кнопки вызывали ошибки
    - Список зарегистрированных обработчиков
"""

print("  ├─ handlers/__init__.py загружен")

# Импортируем модули
from . import website  # Модуль генерации статей для сайтов
from . import reviews  # Модуль работы с отзывами
from . import platform_connections  # Модуль подключения платформ
from . import platform_category  # Меню управления платформами в категориях (модульная структура)
from . import telegram_images_settings  # Настройки изображений для Telegram
from . import pinterest_images_settings  # Настройки изображений для Pinterest

