"""
Обработчик команды /start и главное меню
"""
from telebot import types
from loader import bot
from database.database import db
from config import ADMIN_ID
from utils import escape_html, safe_answer_callback


def send_main_menu(chat_id, message_text=None):
    """
    Отправить главное меню пользователю
    
    Args:
        chat_id: ID чата
        message_text: Текст сообщения (если None - используется приветствие)
    """
    # Создаем клавиатуру главного меню
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    
    # Ряд 1: Проекты | Профиль
    btn_projects = types.KeyboardButton("📁 Проекты")
    btn_profile = types.KeyboardButton("👤 Профиль")
    markup.row(btn_projects, btn_profile)
    
    # Ряд 2: Тарифы | Настройки
    btn_tariffs = types.KeyboardButton("💎 Тарифы")
    btn_settings = types.KeyboardButton("⚙️ Настройки")
    markup.row(btn_tariffs, btn_settings)
    
    # Ряд 3: Админка (только для админа)
    if str(chat_id) == str(ADMIN_ID):
        btn_admin = types.KeyboardButton("🔐 АДМИНКА")
        markup.row(btn_admin)
    
    # Формируем текст приветствия
    if message_text is None:
        user = db.get_user(chat_id)
        if user:
            first_name = user.get('first_name', 'Друг')
            tokens = user.get('tokens', 0) or user.get('balance', 0)
        else:
            first_name = 'Друг'
            tokens = 0
        
        message_text = (
            f"👋 <b>Привет, {escape_html(first_name)}!</b>\n\n"
            "🚀 <b>Добро пожаловать в AI Bot Creator!</b>\n\n"
            
            "💡 <b>Создавайте контент с искусственным интеллектом!</b>\n\n"
            
            "📌 <b>Главная суть проекта:</b>\n"
            "Автоматизируйте создание контента для вашего бизнеса:\n"
            "✅ Генерация SEO-статей для сайта\n"
            "✅ Создание постов для соцсетей\n"
            "✅ Подбор ключевых слов\n"
            "✅ Автопостинг по расписанию\n"
            "✅ Анализ конкурентов\n\n"
            
            "🎯 <b>Что вы получаете:</b>\n"
            "• Экономия времени на создании контента\n"
            "• Профессиональные тексты от AI\n"
            "• Автоматическая публикация\n"
            "• Больше клиентов через SEO\n\n"
            
            f"🎁 <b>ПОЗДРАВЛЯЕМ!</b>\n"
            f"Вам начислено <b>{tokens} токенов</b> в подарок!\n"
            f"Этого хватит на 30+ статей или 150+ постов!\n\n"
            
            "━━━━━━━━━━━━━━\n"
            "👇 <b>Выберите действие или нажмите «Помощь» для инструкций</b>"
        )
    
    # Отправляем сообщение
    try:
        # Добавляем inline-кнопку "Помощь"
        inline_markup = types.InlineKeyboardMarkup()
        inline_markup.add(
            types.InlineKeyboardButton("❓ Помощь", callback_data="help_menu")
        )
        
        bot.send_message(chat_id, message_text, reply_markup=markup, parse_mode='HTML')
        bot.send_message(chat_id, "💡 <b>Нужна помощь?</b> Нажмите кнопку ниже:", 
                        reply_markup=inline_markup, parse_mode='HTML')
    except Exception as e:
        print(f"Ошибка отправки главного меню: {e}")
        # Попытка без HTML форматирования
        try:
            bot.send_message(chat_id, "🏠 Главное меню", reply_markup=markup)
        except Exception as e2:
            print(f"Критическая ошибка отправки меню: {e2}")


@bot.message_handler(commands=['start'])
def handle_start(message):
    """Обработчик команды /start"""
    user_id = message.from_user.id
    username = message.from_user.username or "Guest"
    first_name = message.from_user.first_name or "Друг"
    
    print(f"🚀 /start от пользователя {user_id} (@{username})")
    
    # Регистрируем пользователя если его нет в БД
    try:
        if not db.get_user(user_id):
            db.add_user(user_id, username, first_name)
            print(f"✅ Новый пользователь зарегистрирован: {user_id} ({first_name})")
    except Exception as e:
        print(f"⚠️ Ошибка регистрации пользователя: {e}")
    
    # Отправляем главное меню
    send_main_menu(message.chat.id)
    print(f"✅ Главное меню отправлено для {user_id}")


@bot.message_handler(func=lambda message: message.text == "🔙 Главное меню")
def handle_back_to_menu(message):
    """Обработчик кнопки возврата в главное меню"""
    send_main_menu(message.chat.id, "🏠 Главное меню")


# ═══════════════════════════════════════════════════════════════
# СИСТЕМА ПОМОЩИ
# ═══════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda call: call.data == "help_menu")
def show_help_menu(call):
    """Главное меню помощи"""
    text = """
❓ <b>ПОМОЩЬ И ИНСТРУКЦИИ</b>

Выберите раздел для получения подробной информации:
"""
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🔌 Первое подключение", callback_data="help_first_connection"),
        types.InlineKeyboardButton("🤖 Создание бота", callback_data="help_create_bot"),
        types.InlineKeyboardButton("📂 Категории", callback_data="help_categories"),
        types.InlineKeyboardButton("📅 Публикация и планировщики", callback_data="help_publishing")
    )
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


@bot.callback_query_handler(func=lambda call: call.data == "help_first_connection")
def show_help_first_connection(call):
    """Инструкция по первому подключению"""
    text = """
🔌 <b>ПЕРВОЕ ПОДКЛЮЧЕНИЕ</b>

<b>Шаг 1: Подключите платформы</b>
• Нажмите "⚙️ Настройки" в главном меню
• Выберите нужную платформу для подключения

<b>🌐 WordPress (сайт):</b>
1. Перейдите в WordPress админку
2. Установите плагин "Application Passwords"
3. Создайте пароль приложения
4. В настройках бота введите:
   → URL сайта
   → Логин WordPress
   → Пароль приложения

<b>📌 Pinterest:</b>
1. Создайте бизнес-аккаунт Pinterest
2. Получите токен доступа (Access Token)
3. В настройках бота введите токен

<b>📱 Telegram:</b>
1. Создайте канал в Telegram
2. Добавьте бота как администратора
3. Бот автоматически определит ваш канал

<b>Шаг 2: Создайте проект</b>
• Откройте "📁 Проекты"
• Нажмите "➕ Создать проект"
• Введите название (Например: "Мой сайт")

<b>Шаг 3: Готово!</b>
Теперь можете создавать категории, добавлять контент и публиковать автоматически!

<b>💡 Важно:</b>
Сначала подключите платформы в настройках, потом создавайте проекты!
"""
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="help_menu"))
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


@bot.callback_query_handler(func=lambda call: call.data == "help_create_bot")
def show_help_create_bot(call):
    """Инструкция по созданию бота"""
    text = """
🤖 <b>СОЗДАНИЕ БОТА</b>

<b>Что такое "бот" в системе?</b>
Бот (проект) - это контейнер для вашего бизнеса, куда добавляются категории товаров/услуг и платформы для публикации.

<b>Как создать:</b>
1. Откройте "📁 Проекты"
2. Нажмите "➕ Создать проект"
3. Введите название (Например: "Салон красоты")
4. Готово! Проект создан ✅

<b>Какие платформы можно подключить:</b>

🌐 <b>WordPress</b>
→ Для публикации статей на сайт
→ Автоматическое SEO
→ Поддержка Yoast SEO

📌 <b>Pinterest</b>
→ Создание пинов с изображениями
→ Автопостинг по расписанию
→ SEO-описания

📱 <b>Telegram</b>
→ Посты в канал/группу
→ С текстом и изображениями
→ Поддержка топиков

<b>💡 Совет:</b>
Подключите сразу несколько платформ для максимального охвата аудитории!
"""
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="help_menu"))
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


@bot.callback_query_handler(func=lambda call: call.data == "help_categories")
def show_help_categories(call):
    """Инструкция по категориям"""
    text = """
📂 <b>КАТЕГОРИИ</b>

<b>Что это такое?</b>
Категория - это тематический раздел вашего бизнеса (товар, услуга, направление).

<b>Примеры категорий:</b>
• Для салона: "Маникюр", "Педикюр", "Стрижки"
• Для магазина: "Платья", "Обувь", "Аксессуары"
• Для сайта: "WPC панели", "3D панели", "Декор"

<b>Как создать категорию:</b>
1. Откройте проект
2. Нажмите "➕ Добавить категорию"
3. Введите название
4. Добавьте описание (для AI)

<b>Что настраивается в категории:</b>

🔑 <b>Ключевые слова</b>
→ Фразы для SEO и генерации контента
→ AI подбирает похожие слова автоматически

📝 <b>Контент</b>
→ Тексты описаний
→ Изображения
→ Цены и характеристики

📅 <b>Расписание</b>
→ Автопубликация на платформы
→ Настройка времени и частоты

💡 <b>Совет:</b>
Чем больше информации в категории - тем лучше AI создаст контент!
"""
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="help_menu"))
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


@bot.callback_query_handler(func=lambda call: call.data == "help_publishing")
def show_help_publishing(call):
    """Инструкция по публикации и планировщикам"""
    text = """
📅 <b>ПУБЛИКАЦИЯ И ПЛАНИРОВЩИКИ</b>

<b>Два способа публикации:</b>

📤 <b>1. Вручную (Опубликовать сейчас)</b>
• Создаёт контент прямо сейчас
• Публикует на выбранную платформу
• Использует токены за генерацию

📅 <b>2. Автоматически (Планировщик)</b>
• Настраиваете расписание один раз
• Бот публикует автоматически
• Экономит ваше время

<b>Как настроить планировщик:</b>

1️⃣ Откройте категорию
2️⃣ Нажмите "📅 Глобальный планировщик"
3️⃣ Выберите платформу
4️⃣ Нажмите "⚙️ Изменить расписание"

<b>Настройки расписания:</b>
📆 <b>Дни недели</b> - когда публиковать
🕐 <b>Время</b> - в какое время
📊 <b>Частота</b> - как часто

<b>Пример настройки:</b>
• Дни: Пн, Ср, Пт
• Время: 10:00, 15:00
• Частота: 2 поста в день

= Итого: 6 постов в неделю автоматически!

<b>💡 Рекомендации:</b>
• WordPress: 1-2 статьи в неделю
• Pinterest: 3-5 пинов в день
• Telegram: 1-3 поста в день

<b>📊 Статистика:</b>
В глобальном планировщике есть кнопка "📊 Статистика публикаций" - смотрите результаты!
"""
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="help_menu"))
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


print("✅ handlers/start.py загружен")
