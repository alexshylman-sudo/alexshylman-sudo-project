"""
Генерация отзывов через Claude AI с профессиональным промптом
"""
from telebot import types
from loader import bot
from database.database import db
from utils import escape_html, safe_answer_callback
from config import TOKEN_PRICES
import json
from datetime import datetime, timedelta
import re


# Временное хранилище сгенерированных отзывов
generated_reviews_storage = {}


def get_review_date_range():
    """Возвращает диапазон дат для отзывов (от 12 до 8 месяцев назад)"""
    today = datetime.now()
    date_from = (today - timedelta(days=365)).strftime("%Y-%m-%d")  # 12 месяцев назад
    date_to = (today - timedelta(days=240)).strftime("%Y-%m-%d")    # 8 месяцев назад
    return f"между {date_from} и {date_to}"


@bot.callback_query_handler(func=lambda call: call.data.startswith("gen_reviews_"))
def handle_generate_reviews_start(call):
    """Выбор количества отзывов для генерации"""
    category_id = int(call.data.split("_")[-1])
    user_id = call.from_user.id
    
    # Получаем категорию
    category = db.get_category(category_id)
    if not category:
        safe_answer_callback(bot, call.id, "❌ Категория не найдена", show_alert=True)
        return
    
    category_name = category.get('name', 'Без названия')
    
    # Получаем баланс
    tokens = db.get_user_tokens(user_id)
    
    text = (
        f"🤖 <b>ГЕНЕРАЦИЯ ОТЗЫВОВ</b>\n"
        f"📂 Категория: {escape_html(category_name)}\n"
        "━━━━━━━━━━━━━━\n\n"
        f"💰 Ваш баланс: <b>{tokens:,}</b> токенов\n\n"
        "💡 <b>AI создаст реалистичные отзывы:</b>\n"
        "• Разные имена и даты\n"
        "• Конкретные детали\n"
        "• Плюсы и минусы\n"
        "• Разные оценки (3-5★)\n\n"
        "Выберите количество:"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.row(
        types.InlineKeyboardButton("3 отзыва (30 токенов)", callback_data=f"gen_rev_exec_{category_id}_3"),
        types.InlineKeyboardButton("5 отзывов (50 токенов)", callback_data=f"gen_rev_exec_{category_id}_5")
    )
    markup.row(
        types.InlineKeyboardButton("10 отзывов (100 токенов)", callback_data=f"gen_rev_exec_{category_id}_10")
    )
    markup.add(
        types.InlineKeyboardButton("🔙 Назад", callback_data=f"category_reviews_{category_id}")
    )
    
    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    
    safe_answer_callback(bot, call.id)


@bot.callback_query_handler(func=lambda call: call.data.startswith("gen_rev_exec_"))
def handle_generate_reviews_execute(call):
    """Выполнение генерации отзывов через Claude AI"""
    parts = call.data.split("_")
    category_id = int(parts[3])
    count = int(parts[4])
    
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    
    # Получаем категорию
    category = db.get_category(category_id)
    if not category:
        safe_answer_callback(bot, call.id, "❌ Категория не найдена", show_alert=True)
        return
    
    category_name = category.get('name', '')
    description = category.get('description', '')
    
    # Рассчитываем стоимость
    cost = count * 10
    
    # Проверяем баланс
    tokens = db.get_user_tokens(user_id)
    if tokens < cost:
        bot.answer_callback_query(
            call.id,
            f"❌ Недостаточно токенов! Нужно: {cost}, у вас: {tokens}",
            show_alert=True
        )
        return
    
    # Списываем токены
    if not db.update_tokens(user_id, -cost):
        safe_answer_callback(bot, call.id, "❌ Ошибка списания токенов", show_alert=True)
        return
    
    new_balance = db.get_user_tokens(user_id)
    
    # Показываем прогресс
    bot.edit_message_text(
        f"⏳ Генерирую {count} отзыв(ов) для <b>{escape_html(category_name)}</b>...\n\n"
        f"Это может занять 10-30 секунд.",
        chat_id,
        call.message.message_id,
        parse_mode='HTML'
    )
    safe_answer_callback(bot, call.id)
    
    # Вычисляем диапазон дат
    date_range = get_review_date_range()
    
    # Получаем прайс если есть
    prices = category.get('prices', {})
    prices_text = ""
    if prices and isinstance(prices, dict):
        rows = prices.get('rows', [])
        if rows:
            prices_text = "\n\nЦЕНЫ:\n"
            for item in rows[:5]:  # первые 5 позиций
                name = item.get(list(item.keys())[0] if item.keys() else 'name', '')
                prices_text += f"- {name}\n"
    
    # Формируем УЛУЧШЕННЫЙ промпт для максимально естественных отзывов
    prompt = f"""Ты — настоящий клиент, который пишет отзыв о товаре/услуге.
Твоя задача: создать {count} МАКСИМАЛЬНО ЕСТЕСТВЕННЫХ отзывов, неотличимых от реальных.

═══════════════════════════════════════════════════════

📊 О ЧЁМ ПИШЕМ:

Товар/Услуга: {category_name}
"""
    
    if description:
        prompt += f"Описание: {description}\n"
    
    if prices_text:
        prompt += prices_text
    
    prompt += f"""

═══════════════════════════════════════════════════════

⚠️ ГЛАВНОЕ: ИЗБЕГАЙ ИСКУССТВЕННОСТИ!

🚫 НЕ ПИШИ КАК МАРКЕТОЛОГ:
❌ "идеальным решением", "не пожалела", "очень довольна результатом"
❌ "отличный выбор", "рекомендую всем", "превзошло ожидания"
❌ Избыточные хвалебные формулировки
❌ Перечисление всех преимуществ продукта
❌ Слишком структурированный текст

✅ ПИШИ КАК ОБЫЧНЫЙ ЧЕЛОВЕК:
✅ Начни с эмоции или проблемы: "Наконец-то!", "Долго думали...", "Попробовали и..."
✅ Естественные обрывы мысли: "...в общем довольны", "короче говоря"
✅ Разговорные словечки: "реально", "норм", "вообще", "кста", "прям"
✅ Неидеальная грамматика: пропущенные запятые, разговорный стиль
✅ Личный опыт: "у нас", "мы делали", "я выбирала"

═══════════════════════════════════════════════════════

🎭 ЕСТЕСТВЕННЫЕ ПАТТЕРНЫ:

1️⃣ НАЧАЛО ОТЗЫВА (разнообразь!):
✅ "Взяли для ванной..."
✅ "Долго выбирали, остановились на..."
✅ "Реально понравилось!"
✅ "Ну что сказать..."
✅ "Наконец-то решились"
✅ "Делали ремонт и..."
❌ "Выражаю благодарность компании..."
❌ "Являюсь клиентом компании..."

2️⃣ СТРУКТУРА (НЕ ВСЕГДА ЛОГИЧНА!):
✅ Сначала эмоция, потом детали
✅ Перескакивание с темы на тему
✅ Повторение важного
✅ Незавершённые мысли
❌ Чёткое: "Плюсы: 1, 2, 3. Минусы: 1, 2"
❌ Последовательное изложение

3️⃣ ЭМОЦИОНАЛЬНОСТЬ:
✅ Восклицания! ("Вообще огонь!")
✅ Многоточия... (задумчивость)
✅ Скобочки (уточнения)
✅ Смайлы допустимы: ) или :)
✅ КАПС для эмоций (но редко!)
❌ Полностью рациональный тон
❌ Бизнес-формулировки

4️⃣ ДЛИНА И СТИЛЬ:

🔹 КОРОТКИЕ (30% отзывов) - 2-4 предложения:
"Взяли для кухни. Смотрится отлично, монтаж быстрый. Доволен результатом)"

🔹 СРЕДНИЕ (50%) - 4-7 предложений:
Неравномерные абзацы, живая речь, конкретика. Может быть небольшой минус или уточнение.

🔹 РАЗВЁРНУТЫЕ (20%) - 8-15 предложений:
Рассказ с деталями, история выбора, процесс работы, впечатления. Но БЕЗ маркетингового пафоса!

═══════════════════════════════════════════════════════

5️⃣ ИМЕНА (МАКСИМАЛЬНОЕ РАЗНООБРАЗИЕ!):

✅ Женские: Екатерина, Марина, Ольга, Светлана, Анна, Наталья, Ирина
✅ Мужские: Дмитрий, Андрей, Сергей, Александр, Владимир, Игорь, Максим
✅ С отчеством: Игорь Владимирович, Ольга Сергеевна (редко, звучит официально)
✅ С инициалом: Марина К., Александр Б., Дмитрий С.
✅ Уменьшительные: Катя, Саша (неформально)
✅ Только фамилия: Петров, Соколова (редко)

⚠️ НЕ ПОВТОРЯЙ имена! Каждый отзыв = новый человек!

═══════════════════════════════════════════════════════

6️⃣ ДАТЫ (РАВНОМЕРНОЕ РАСПРЕДЕЛЕНИЕ!):

Используй даты {date_range}
⚠️ НЕ кучкуй все отзывы в 1-2 месяца!
✅ Распредели РАВНОМЕРНО по всему диапазону

Формат: YYYY-MM-DD

═══════════════════════════════════════════════════════

7️⃣ ОЦЕНКИ И СООТВЕТСТВИЕ ТЕКСТУ:

⭐⭐⭐⭐⭐ (5★) - 60% отзывов:
• ТЕКСТ: Очень доволен, всё отлично (но БЕЗ пафоса!)
• ПЛЮСЫ: Конкретные ("Быстро установили", "Цена адекватная")
• МИНУСЫ: ПУСТО или "Не обнаружил" или просто "-"

⭐⭐⭐⭐ (4★) - 30% отзывов:
• ТЕКСТ: Хорошо, но есть небольшой минус
• ПЛЮСЫ: Что понравилось
• МИНУСЫ: ОБЯЗАТЕЛЬНЫ! Но небольшие:
  - "Доставка задержалась на 2 дня"
  - "Немного пыльно было при монтаже"
  - "Консультация была короткая"

⭐⭐⭐ (3★) - 10% отзывов:
• ТЕКСТ: Нормально, но есть претензии
• ПЛЮСЫ: Что-то всё же хорошо
• МИНУСЫ: СЕРЬЁЗНЫЕ:
  - "Качество не супер, как ожидали"
  - "Монтаж долгий получился"
  - "Цена выше чем у конкурентов"

═══════════════════════════════════════════════════════

8️⃣ КОНКРЕТИКА (КРИТИЧНО ДЛЯ ЕСТЕСТВЕННОСТИ!):

✅ Размеры: "стена 4 на 3 метра", "комната 20 квадратов"
✅ Время: "монтаж за 4 часа", "сделали за выходные", "неделя ушла"
✅ Сравнения: "смотрели обои - дороже вышло", "у соседей другие взяли"
✅ Количество: "3 упаковки хватило", "заказывали 15 кв.м."
✅ Цены (примерно): "уложились в 30 тысяч", "вышло дешевле чем думали"
✅ Место: "для спальни", "на кухню", "в гостиную"
✅ Детали: "цвет серый выбрали", "матовый вариант", "под дерево"

❌ Избегай: "замечательно", "превосходно", "идеально" (слишком маркетингово)

═══════════════════════════════════════════════════════

9️⃣ ПРИМЕРЫ ЕСТЕСТВЕННЫХ ФРАЗ:

НАЧАЛО:
• "Взяли для кухни после долгих раздумий..."
• "Наконец решились на ремонт и..."
• "Делали спальню, выбирали долго..."
• "Реально понравился результат!"
• "Ну что сказать, доволен)"

СЕРЕДИНА:
• "...монтаж правда быстрый был"
• "...в общем норм получилось"
• "...кста цена адекватная"
• "...хотя сначала сомневались"
• "...короче говоря, рекомендую"

КОНЕЦ:
• "В целом довольны результатом"
• "Вроде всё нормально пока"
• "Посмотрим как дальше будет)"
• "Пока что всё ок"
• "Думаю хороший выбор сделали"

═══════════════════════════════════════════════════════

🔟 НЕ ИСПОЛЬЗУЙ (УБИРАЕТ ЕСТЕСТВЕННОСТЬ):

❌ SEO-спам: "где купить в Москве", "цена", "заказать дешево"
❌ Шаблоны: "Огромное спасибо компании", "Выражаю благодарность"
❌ Пафос: "идеальное решение", "лучший выбор в жизни"
❌ Перечисление всех преимуществ подряд
❌ Структура "Плюсы: 1, 2, 3. Минусы: 1, 2, 3" (слишком официально)
❌ Одинаковые имена и даты
❌ Избыточная вежливость

═══════════════════════════════════════════════════════

📝 ФОРМАТ ВЫВОДА (СТРОГО JSON):

```json
[
  {{
    "author": "Естественное имя (разное каждый раз!)",
    "date": "YYYY-MM-DD (равномерно распределены)",
    "rating": 5,
    "text": "Живой текст с эмоциями, конкретикой, разговорным стилем. Может быть неидеальная грамматика. Многоточия... и восклицания! Обрывы мысли. В общем, как реальный человек пишет.",
    "pros": "Конкретные плюсы (не маркетинговые фразы!)",
    "cons": "5★=пусто или '-', 4★=небольшой минус, 3★=серьёзная претензия",
    "project": "Конкретное место установки (кухня, спальня, ванная и т.д.)"
  }}
]
```

⚠️ КРИТИЧЕСКИ ВАЖНО:
1. Каждый отзыв = уникальное имя
2. Даты равномерно по {date_range}
3. Живой разговорный язык (не маркетинговый!)
4. Конкретика (размеры, время, место)
5. Естественные эмоции и обрывы мысли
6. Минусы соответствуют оценке (4★=есть, 3★=серьёзные)

ВЫВЕДИ ТОЛЬКО JSON МАССИВ, БЕЗ ПОЯСНЕНИЙ!

НАЧНИ ГЕНЕРАЦИЮ {count} ЕСТЕСТВЕННЫХ ОТЗЫВОВ:"""
    
    try:
        # Вызываем Claude API
        from ai.text_generator import client
        
        if not client:
            raise Exception("Claude API не настроен")
        
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        
        # Извлекаем текст
        response_text = response.content[0].text
        
        # Парсим JSON
        json_match = re.search(r'\[.*\]', response_text, re.DOTALL)
        if not json_match:
            raise ValueError("Не найден JSON в ответе")
        
        reviews_data = json.loads(json_match.group())
        
        if not reviews_data:
            raise ValueError("Пустой список отзывов")
        
        # Сохраняем во временное хранилище
        generated_reviews_storage[chat_id] = {
            'category_id': category_id,
            'reviews': reviews_data
        }
        
        # Показываем первый отзыв как превью
        first_review = reviews_data[0]
        stars = "★" * first_review['rating'] + "☆" * (5 - first_review['rating'])
        
        text = (
            f"✅ <b>Сгенерировано {len(reviews_data)} отзыв(ов)!</b>\n\n"
            f"💳 <b>Списано:</b> {cost} токенов\n"
            f"💰 <b>Баланс:</b> {new_balance:,} токенов\n\n"
            f"<b>Превью первого отзыва:</b>\n\n"
            f"{stars} <b>{first_review['author']}</b> | {first_review['date']}\n\n"
            f"{first_review['text']}\n\n"
            f"<b>Плюсы:</b> {first_review.get('pros', 'Не указано')}\n"
        )
        
        if first_review.get('cons'):
            text += f"<b>Минусы:</b> {first_review['cons']}\n"
        
        text += f"\n<b>Проект:</b> {first_review.get('project', 'Не указано')}"
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton(f"✅ Сохранить {len(reviews_data)} отзыв(ов)", callback_data=f"save_reviews_{category_id}"),
            types.InlineKeyboardButton("🔄 Сгенерировать заново", callback_data=f"gen_reviews_{category_id}"),
            types.InlineKeyboardButton("❌ Отменить", callback_data=f"category_reviews_{category_id}")
        )
        
        bot.edit_message_text(
            text,
            chat_id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
        
    except Exception as e:
        print(f"❌ Ошибка генерации отзывов: {e}")
        import traceback
        traceback.print_exc()
        
        # Возвращаем токены
        db.update_tokens(user_id, cost)
        
        bot.edit_message_text(
            f"❌ Ошибка генерации отзывов: {e}\n\n"
            f"Токены возвращены на ваш счёт.",
            chat_id,
            call.message.message_id
        )


@bot.callback_query_handler(func=lambda call: call.data.startswith("save_reviews_"))
def handle_save_reviews(call):
    """Сохранение сгенерированных отзывов"""
    category_id = int(call.data.split("_")[-1])
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    
    # Получаем отзывы из хранилища
    if chat_id not in generated_reviews_storage:
        safe_answer_callback(bot, call.id, "❌ Отзывы не найдены", show_alert=True)
        return
    
    reviews_data = generated_reviews_storage[chat_id]['reviews']
    
    try:
        # Сохраняем в БД
        db.cursor.execute("""
            UPDATE categories
            SET reviews = %s::jsonb
            WHERE id = %s
        """, (json.dumps(reviews_data, ensure_ascii=False), category_id))
        db.conn.commit()
        
        # Очищаем хранилище
        del generated_reviews_storage[chat_id]
        
        text = (
            f"✅ <b>ОТЗЫВЫ СОХРАНЕНЫ</b>\n"
            "━━━━━━━━━━━━━━\n\n"
            f"📊 Сохранено: <b>{len(reviews_data)}</b> отзывов\n\n"
            "Отзывы успешно добавлены в категорию!"
        )
        
        markup = types.InlineKeyboardMarkup()
        markup.add(
            types.InlineKeyboardButton("🔙 К отзывам", callback_data=f"category_reviews_{category_id}")
        )
        
        bot.edit_message_text(
            text,
            chat_id,
            call.message.message_id,
            reply_markup=markup,
            parse_mode='HTML'
        )
        
        safe_answer_callback(bot, call.id, "✅ Сохранено")
        
    except Exception as e:
        print(f"❌ Ошибка сохранения: {e}")
        safe_answer_callback(bot, call.id, "❌ Ошибка сохранения", show_alert=True)


@bot.callback_query_handler(func=lambda call: call.data.startswith("view_all_reviews_"))
def handle_view_all_reviews(call):
    """Просмотр всех отзывов категории"""
    category_id = int(call.data.split("_")[-1])
    
    # Получаем категорию
    category = db.get_category(category_id)
    if not category:
        safe_answer_callback(bot, call.id, "❌ Категория не найдена", show_alert=True)
        return
    
    category_name = category.get('name', 'Без названия')
    reviews = category.get('reviews', [])
    
    if not reviews or not isinstance(reviews, list):
        safe_answer_callback(bot, call.id, "❌ Нет отзывов", show_alert=True)
        return
    
    # Формируем текст со всеми отзывами
    text = (
        f"⭐️ <b>ВСЕ ОТЗЫВЫ</b>\n"
        f"📂 Категория: {escape_html(category_name)}\n"
        "━━━━━━━━━━━━━━\n\n"
        f"📊 Всего отзывов: <b>{len(reviews)}</b>\n\n"
    )
    
    # Добавляем все отзывы
    for i, review in enumerate(reviews, 1):
        rating = review.get('rating', 5)
        stars = "★" * rating + "☆" * (5 - rating)
        author = review.get('author', 'Аноним')
        date = review.get('date', '')
        review_text = review.get('text', '')
        pros = review.get('pros', '')
        cons = review.get('cons', '')
        
        text += f"<b>{i}. {stars} {escape_html(author)}</b>"
        if date:
            text += f" | {date}"
        text += "\n\n"
        
        # Ограничиваем длину текста отзыва для списка
        if len(review_text) > 150:
            text += f"{escape_html(review_text[:150])}...\n"
        else:
            text += f"{escape_html(review_text)}\n"
        
        if pros:
            text += f"✅ {escape_html(pros)}\n"
        
        if cons:
            text += f"❌ {escape_html(cons)}\n"
        
        text += "\n"
    
    text += "━━━━━━━━━━━━━━"
    
    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton("🔙 Назад", callback_data=f"category_reviews_{category_id}")
    )
    
    # Удаляем предыдущее сообщение
    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)
    except:
        pass
    
    # Отправляем новое (может быть очень длинным)
    try:
        bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='HTML')
    except Exception as e:
        # Если слишком длинное - показываем первые 5
        if "message is too long" in str(e).lower():
            short_text = (
                f"⭐️ <b>ОТЗЫВЫ (первые 5)</b>\n"
                f"📂 Категория: {escape_html(category_name)}\n"
                "━━━━━━━━━━━━━━\n\n"
                f"📊 Всего отзывов: <b>{len(reviews)}</b>\n\n"
            )
            
            for i, review in enumerate(reviews[:5], 1):
                rating = review.get('rating', 5)
                stars = "★" * rating + "☆" * (5 - rating)
                author = review.get('author', 'Аноним')
                date = review.get('date', '')
                review_text = review.get('text', '')
                
                short_text += f"<b>{i}. {stars} {escape_html(author)}</b>"
                if date:
                    short_text += f" | {date}"
                short_text += f"\n{escape_html(review_text[:100])}...\n\n"
            
            short_text += f"<i>... и ещё {len(reviews) - 5} отзывов</i>\n\n━━━━━━━━━━━━━━"
            
            bot.send_message(call.message.chat.id, short_text, reply_markup=markup, parse_mode='HTML')
        else:
            safe_answer_callback(bot, call.id, f"❌ Ошибка: {e}", show_alert=True)
    
    safe_answer_callback(bot, call.id)
