# 🚀 БЫСТРЫЙ СТАРТ

## За 5 минут до запуска бота

---

## 📋 ШАГ 1: Подготовка окружения

### Установите зависимости:

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y python3 python3-pip postgresql postgresql-contrib

# CentOS/RHEL
sudo yum install -y python3 python3-pip postgresql postgresql-server
```

---

## 📦 ШАГ 2: Распаковка проекта

```bash
# Распаковать архив
unzip FULL_PROJECT_STABLE.zip -d telegram-bot
cd telegram-bot

# Установить Python зависимости
pip3 install -r requirements.txt
```

---

## 🗄️ ШАГ 3: Настройка базы данных

```bash
# Создать базу данных
sudo -u postgres psql -c "CREATE DATABASE telegram_bot;"
sudo -u postgres psql -c "CREATE USER botuser WITH PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE telegram_bot TO botuser;"

# Инициализировать схему
psql -U botuser -d telegram_bot -f database/schema.sql
```

---

## 🔑 ШАГ 4: Настройка API ключей

Создайте файл `.env` в корне проекта:

```bash
nano .env
```

Вставьте:

```env
# Telegram Bot Token (от @BotFather)
TELEGRAM_BOT_TOKEN=123456:ABCdefGHIjklMNOpqrsTUVwxyz

# PostgreSQL
DATABASE_URL=postgresql://botuser:your_password@localhost:5432/telegram_bot

# Anthropic API (Claude) - для генерации текста
ANTHROPIC_API_KEY=sk-ant-api03-...

# Banana API (Nano) - для генерации изображений  
BANANA_API_KEY=your_banana_key_here
BANANA_MODEL_KEY=your_model_key_here
```

**Где получить ключи:**

- **Telegram Bot Token**: [@BotFather](https://t.me/BotFather) → `/newbot`
- **Anthropic API**: [console.anthropic.com](https://console.anthropic.com)
- **Banana API**: [banana.dev](https://banana.dev)

---

## ▶️ ШАГ 5: Запуск

```bash
# Запустить бота
python3 main.py
```

Вы увидите:
```
✅ База данных подключена
✅ Все модули загружены
🤖 Бот запущен!
```

---

## 🧪 ШАГ 6: Первая проверка

1. Откройте Telegram
2. Найдите вашего бота по username
3. Отправьте `/start`
4. Должно появиться приветственное меню

---

## 📊 ШАГ 7: Создание первой статьи

### В боте:

1. **Создать проект** (бот)
   - Название: "Мой сайт"
   - Описание: любое

2. **Подключить WordPress**
   - Меню → Подключения → Website
   - URL сайта: `https://ваш-сайт.ru`
   - Логин и пароль приложения

3. **Создать категорию**
   - Название: "Товары"
   - Описание: краткое описание

4. **Добавить ключевые слова**
   - "стеновые панели"
   - "ламинат для дома"
   - "натяжные потолки"
   - и т.д. (минимум 5)

5. **Добавить прайс-лист** (опционально)
   - Вручную или из Excel

6. **Генерировать статью!**
   - Выбрать категорию → Website → Генерировать
   - Статья будет создана и опубликована автоматически

---

## 🔧 НАСТРОЙКИ (опционально)

### Объём статьи:
- Website → Объём статьи
- Выбрать от 800 до 5000 слов
- По умолчанию: 1500 слов

### Изображения:
- Website → Изображения
- Количество: 1-10
- Форматы: 16:9, 1:1, 9:16, 4:3
- Стили: реализм, профи-фото, интерьер, минимализм, luxury

---

## 💰 ТОКЕНЫ

### Пополнение баланса:
- Админ может начислять токены через админ-панель
- Или настроить платежную систему

### Расход токенов:
- Текст: ~10 токенов за 100 слов
- Изображение: ~30 токенов
- Статья 1500 слов + 3 фото ≈ 240 токенов

---

## 🐛 ЧАСТЫЕ ПРОБЛЕМЫ

### Бот не запускается:

```bash
# Проверить зависимости
pip3 list | grep -E "telebot|anthropic|psycopg2"

# Переустановить если нужно
pip3 install pyTelegramBotAPI anthropic psycopg2-binary --upgrade
```

### База данных не подключается:

```bash
# Проверить что PostgreSQL запущен
sudo systemctl status postgresql

# Запустить если нужно
sudo systemctl start postgresql
```

### Ошибки API ключей:

- Проверьте файл `.env`
- Убедитесь что ключи правильные
- Проверьте баланс на Anthropic/Banana

---

## 📱 КОМАНДЫ БОТА

- `/start` - Главное меню
- `/help` - Помощь
- `/balance` - Баланс токенов
- `/stats` - Статистика

---

## 🎉 ГОТОВО!

Ваш бот готов к работе!

Для продвинутых настроек смотрите `FULL_PROJECT_README.md`
