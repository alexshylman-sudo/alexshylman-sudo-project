"""
Система миграций базы данных
"""
print("✅ database/migrations/__init__.py загружен")
