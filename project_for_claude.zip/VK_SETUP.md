# 🔵 VK OAuth Интеграция - Инструкция по настройке

## ✅ Что уже сделано:

1. **VK Config** (`handlers/vk_integration/vk_config.py`)
   - Конфигурация VK App
   - Генерация URL авторизации

2. **VK OAuth Handler** (`handlers/vk_integration/vk_oauth.py`)
   - Обмен code на token
   - Получение данных пользователя
   - Сохранение в БД

3. **Telegram Handler** (`handlers/vk_integration/vk_telegram_handler.py`)
   - Кнопка "Подключить VK"
   - Проверка статуса подключения
   - Отключение VK

4. **Webhook Server** (`vk_webhook.py`)
   - Flask сервер для обработки callback
   - Красивые страницы успеха/ошибки
   - Health check endpoint

---

## 📋 Что нужно сделать:

### 1. Добавить переменную окружения на Render.com

Зайди в настройки твоего проекта на Render.com:

```
https://dashboard.render.com
→ Твой проект (alexshylman-sudo-project)
→ Environment
→ Add Environment Variable
```

Добавь:
```
Ключ: VK_APP_SECRET
Значение: твой_сервисный_ключ_vk
```

### 2. Настроить Redirect URI в VK

Зайди в настройки VK приложения:
```
https://vk.com/editapp?id=54431232
→ Настройки
→ Доверенный redirect URI для OAuth
```

Добавь:
```
https://alexshylman-sudo-project.onrender.com/vk_callback
```

### 3. Обновить handlers/__init__.py

Добавь в конец файла `handlers/__init__.py`:

```python
# VK Integration
try:
    from handlers.vk_integration import *
    print("✅ VK Integration загружен")
except Exception as e:
    print(f"⚠️ VK Integration не загружен: {e}")
```

### 4. Запустить webhook сервер

На Render.com в настройках **Build & Deploy** измени команду запуска:

**Было:**
```
python main.py
```

**Должно быть:**
```
python vk_webhook.py & python main.py
```

Или создай отдельный сервис на Render.com для webhook.

---

## 🎯 Как использовать:

### Для пользователя:

1. В боте появится кнопка **"Подключить VK"**
2. Пользователь нажимает → открывается VK
3. VK просит разрешение → пользователь подтверждает
4. Перенаправление на твой сервер → сохранение в БД
5. Уведомление в Telegram: "✅ VK подключен!"

### Добавить кнопку в главное меню:

В любом месте где нужна кнопка подключения VK:

```python
markup.add(
    types.InlineKeyboardButton(
        "🔵 Подключить VK",
        callback_data="connect_vk"
    )
)
```

Или проверить статус:

```python
markup.add(
    types.InlineKeyboardButton(
        "🔵 VK Аккаунт",
        callback_data="check_vk_connection"
    )
)
```

---

## 🔍 Проверка работы:

### 1. Проверь что webhook запущен:
```
https://alexshylman-sudo-project.onrender.com/health
```
Должен вернуть: `{"status": "ok"}`

### 2. Проверь логи на Render.com:
```
Dashboard → Logs
```
Должны быть:
```
✅ VK Config загружен
✅ VK OAuth Handler загружен
✅ VK Telegram Handler загружен
✅ VK Webhook Server готов к запуску
```

### 3. Проверь что VK App настроен:
```
https://vk.com/editapp?id=54431232
→ Настройки
```
- Redirect URI указан правильно
- Права доступа включены (email, photos)

---

## 🐛 Возможные ошибки:

### "VK_APP_SECRET not set"
→ Не добавлена переменная окружения на Render.com

### "Redirect URI mismatch"
→ В VK App указан неправильный Redirect URI

### "Connection refused"
→ Webhook сервер не запущен или порт заблокирован

### "User not found"
→ Пользователь не зарегистрирован в боте (нужно сначала `/start`)

---

## 📦 Структура файлов:

```
handlers/
  vk_integration/
    __init__.py
    vk_config.py         # Конфигурация VK
    vk_oauth.py          # OAuth логика
    vk_telegram_handler.py  # Telegram обработчики

vk_webhook.py           # Flask webhook сервер

VK_SETUP.md            # Эта инструкция
```

---

## ✅ Готово!

После настройки пользователи смогут подключать VK одной кнопкой!

Любые вопросы? Пиши!
