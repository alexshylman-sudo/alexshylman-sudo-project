"""
Конфигурация поддерживаемых CMS платформ
"""

# Поддерживаемые CMS платформы
SUPPORTED_CMS = {
    'wordpress': {
        'name': 'WordPress',
        'emoji': '🌐',
        'api_type': 'REST API',
        'requires': ['url', 'username', 'app_password'],
        'instruction': """
🌐 <b>ПОДКЛЮЧЕНИЕ WORDPRESS</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Создайте пароль приложения</b>
1. Войдите в админку WordPress
2. Откройте: Пользователи → Профиль
3. Прокрутите вниз до "Пароли приложений"
4. Введите название: "Telegram Bot"
5. Нажмите "Добавить новый пароль"
6. Скопируйте сгенерированный пароль

<b>Шаг 2: Данные для подключения</b>
• URL сайта: https://ваш-сайт.ru
• Имя пользователя: ваш_логин
• Пароль приложения: скопированный_пароль

<b>📝 Примечания:</b>
• WordPress должен быть версии 5.6+
• Включен REST API (по умолчанию включен)
• SSL сертификат (https://) рекомендуется

<b>🔗 Полная инструкция:</b>
https://make.wordpress.org/core/2020/11/05/application-passwords-integration-guide/
""",
        'test_endpoint': '/wp-json/wp/v2/posts'
    },
    
    'joomla': {
        'name': 'Joomla',
        'emoji': '🔷',
        'api_type': 'REST API',
        'requires': ['url', 'api_token'],
        'instruction': """
🔷 <b>ПОДКЛЮЧЕНИЕ JOOMLA</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Включите API</b>
1. Войдите в админку Joomla
2. Система → Глобальная конфигурация
3. Вкладка "API"
4. Включите "Web Services"
5. Сохраните изменения

<b>Шаг 2: Создайте API токен</b>

1. Пользователи → Управление
2. Создайте нового пользователя или выберите существующего
3. Во вкладке "Токены API" создайте новый токен
4. Скопируйте токен

<b>Шаг 3: Данные для подключения</b>
• URL сайта: https://ваш-сайт.ru
• API токен: скопированный_токен

<b>📝 Примечания:</b>
• Joomla должна быть версии 4.0+
• Требуется HTTPS соединение
• Пользователь должен иметь права на публикацию

<b>🔗 Документация:</b>
https://docs.joomla.org/J4.x:Joomla_Core_APIs
""",
        'test_endpoint': '/api/index.php/v1/content/articles'
    },
    
    'shopify': {
        'name': 'Shopify',
        'emoji': '🛍',
        'api_type': 'Admin API',
        'requires': ['shop_url', 'api_key', 'api_secret'],
        'instruction': """
🛍 <b>ПОДКЛЮЧЕНИЕ SHOPIFY</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Создайте приложение</b>
1. Войдите в админку Shopify
2. Настройки → Приложения и каналы продаж
3. Разработка приложений
4. Создать приложение
5. Введите название: "Telegram Bot"

<b>Шаг 2: Настройте доступ</b>
1. Вкладка "Configuration"
2. Admin API integration → Configure
3. Выберите права:
   • read_products, write_products
   • read_content, write_content
4. Сохраните

<b>Шаг 3: Получите ключи</b>
1. Вкладка "API credentials"
2. Скопируйте:
   • Admin API access token
   • API key
   • API secret key

<b>Шаг 4: Данные для подключения</b>
• Shop URL: ваш-магазин.myshopify.com
• API Key: скопированный_ключ
• API Secret: скопированный_секрет
• Access Token: скопированный_токен

<b>📝 Примечания:</b>
• Используйте URL вида: shop-name.myshopify.com
• Все данные храните в безопасности
• Минимальные права для работы бота

<b>🔗 Документация:</b>
https://shopify.dev/docs/apps/auth/admin-app-access-tokens
""",
        'test_endpoint': '/admin/api/2024-01/products.json'
    },
    
    'wix': {
        'name': 'Wix',
        'emoji': '🎨',
        'api_type': 'REST API',
        'requires': ['site_id', 'api_key'],
        'instruction': """
🎨 <b>ПОДКЛЮЧЕНИЕ WIX</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Получите API ключ</b>
1. Перейдите на Wix Developers: https://dev.wix.com
2. Создайте новое приложение
3. Настройте OAuth → API Key Management
4. Создайте API Key
5. Выберите нужные разрешения:
   • Manage Blog
   • Manage Products
   • Manage Media

<b>Шаг 2: Найдите Site ID</b>
1. Откройте ваш сайт в редакторе Wix
2. URL содержит Site ID
3. Формат: https://manage.wix.com/dashboard/[SITE_ID]/home

<b>Шаг 3: Данные для подключения</b>
• Site ID: из URL редактора
• API Key: сгенерированный ключ

<b>📝 Примечания:</b>
• Требуется премиум план Wix
• API ключ действует неограниченно
• Можно отозвать в любой момент

<b>🔗 Документация:</b>
https://dev.wix.com/api/rest/getting-started
""",
        'test_endpoint': '/v1/sites/{site_id}/blog/posts'
    },
    
    'squarespace': {
        'name': 'Squarespace',
        'emoji': '⬛️',
        'api_type': 'REST API',
        'requires': ['site_url', 'api_key'],
        'instruction': """
⬛️ <b>ПОДКЛЮЧЕНИЕ SQUARESPACE</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Включите API</b>
1. Войдите в панель Squarespace
2. Настройки → Расширенные
3. API Keys
4. Create API Key

<b>Шаг 2: Настройте доступ</b>
1. Название ключа: "Telegram Bot"
2. Выберите права:
   • Read Content
   • Write Content
   • Read Products
   • Write Products
3. Создайте ключ
4. Скопируйте сгенерированный ключ

<b>Шаг 3: Данные для подключения</b>
• Site URL: https://ваш-сайт.squarespace.com
• API Key: скопированный_ключ

<b>📝 Примечания:</b>
• Требуется Business или Commerce план
• API ключи не истекают
• Храните ключ в безопасности

<b>🔗 Документация:</b>
https://developers.squarespace.com/
""",
        'test_endpoint': '/api/1.0/commerce/products'
    },
    
    'opencart': {
        'name': 'OpenCart',
        'emoji': '🛒',
        'api_type': 'REST API',
        'requires': ['url', 'api_key'],
        'instruction': """
🛒 <b>ПОДКЛЮЧЕНИЕ OPENCART</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Включите REST API</b>
1. Войдите в админку OpenCart
2. Система → Пользователи → API
3. Добавить нового API пользователя
4. Заполните:
   • Имя: Telegram Bot
   • Ключ: (автогенерируется)
   • Статус: Включен

<b>Шаг 2: Установите расширение</b>
OpenCart требует установки REST API расширения:
1. Скачайте REST API extension
2. Установите через Extension Installer
3. Активируйте расширение

<b>Шаг 3: Данные для подключения</b>
• URL магазина: https://ваш-магазин.ru
• API Key: сгенерированный_ключ

<b>📝 Примечания:</b>
• Работает с OpenCart 3.0+
• Требуется отдельное расширение для REST API
• Проверьте права доступа API

<b>🔗 Полезные ссылки:</b>
• REST API: https://github.com/opencart/opencart/wiki/API
• Расширение: https://www.opencart.com/index.php?route=marketplace/extension
""",
        'test_endpoint': '/index.php?route=api/product'
    },
    
    'prestashop': {
        'name': 'PrestaShop',
        'emoji': '🏬',
        'api_type': 'Web Service',
        'requires': ['url', 'api_key'],
        'instruction': """
🏬 <b>ПОДКЛЮЧЕНИЕ PRESTASHOP</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Включите Web Service</b>
1. Войдите в панель PrestaShop
2. Расширенные параметры → Web Service
3. Включите: "Включить Web Service PrestaShop"
4. Сохраните

<b>Шаг 2: Создайте API ключ</b>
1. В том же разделе нажмите "Добавить новый ключ"
2. Заполните:
   • Описание ключа: Telegram Bot
   • Статус: Включен
3. Установите права доступа:
   • products: GET, POST, PUT
   • images: GET, POST
   • content: GET, POST
4. Сгенерируйте и скопируйте ключ

<b>Шаг 3: Данные для подключения</b>
• URL магазина: https://ваш-магазин.ru
• Web Service Key: скопированный_ключ

<b>📝 Примечания:</b>
• PrestaShop 1.7+ поддерживает Web Service
• Ключ имеет вид: 32 символа
• CGI режим должен быть включен

<b>🔗 Документация:</b>
https://devdocs.prestashop.com/1.7/webservice/
""",
        'test_endpoint': '/api/products'
    },
    
    'drupal': {
        'name': 'Drupal',
        'emoji': '🔵',
        'api_type': 'JSON:API',
        'requires': ['url', 'client_id', 'client_secret'],
        'instruction': """
🔵 <b>ПОДКЛЮЧЕНИЕ DRUPAL</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Включите модули</b>
1. Войдите в админку Drupal
2. Extend → Установите модули:
   • JSON:API
   • Simple OAuth
3. Configuration → Web services → Simple OAuth

<b>Шаг 2: Создайте OAuth приложение</b>
1. Configuration → People → OAuth2 Clients
2. Add Client
3. Заполните:
   • Label: Telegram Bot
   • Is Confidential: Да
   • New Secret: (автогенерируется)
4. Скопируйте Client ID и Secret

<b>Шаг 3: Настройте права</b>
1. People → Roles
2. Создайте роль: "API User"
3. Дайте права:
   • Access content
   • Create content
   • Edit own content

<b>Шаг 4: Данные для подключения</b>
• URL сайта: https://ваш-сайт.ru
• Client ID: скопированный_id
• Client Secret: скопированный_секрет

<b>📝 Примечания:</b>
• Drupal 8.7+ или Drupal 9+
• Модуль Simple OAuth обязателен
• HTTPS строго рекомендуется

<b>🔗 Документация:</b>
https://www.drupal.org/docs/core-modules-and-themes/core-modules/jsonapi-module
""",
        'test_endpoint': '/jsonapi/node/article'
    },
    
    'bitrix': {
        'name': '1C-Bitrix',
        'emoji': '🟠',
        'api_type': 'REST API',
        'requires': ['portal_url', 'webhook_url'],
        'instruction': """
🟠 <b>ПОДКЛЮЧЕНИЕ 1C-BITRIX</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Создайте вебхук</b>
1. Войдите в Битрикс24
2. Разработчикам → Другое → Входящий вебхук
3. Или: Настройки → Настройки REST API → Входящий вебхук
4. Нажмите "Создать вебхук"

<b>Шаг 2: Настройте права</b>
Выберите необходимые права доступа:
• Диск (disk): чтение, запись
• Пользователи (user): чтение
• CRM (crm): чтение, запись (если нужно)
• Блог (blog): чтение, запись (если есть)

<b>Шаг 3: Получите URL вебхука</b>
После создания скопируйте полный URL:
https://ваш-портал.bitrix24.ru/rest/1/xxxxxxxx/

<b>Шаг 4: Данные для подключения</b>
• Portal URL: https://ваш-портал.bitrix24.ru
• Webhook URL: полный_url_вебхука

<b>📝 Примечания:</b>
• Работает с Битрикс24 и коробочной версией
• Вебхук не истекает
• Можно отозвать в любой момент

<b>🔗 Документация:</b>
https://dev.1c-bitrix.ru/rest_help/
""",
        'test_endpoint': '/rest/user.current'
    },
    
    'tilda': {
        'name': 'Tilda',
        'emoji': '🎯',
        'api_type': 'REST API',
        'requires': ['public_key', 'secret_key'],
        'instruction': """
🎯 <b>ПОДКЛЮЧЕНИЕ TILDA</b>
━━━━━━━━━━━━━━━━━━

<b>Шаг 1: Получите API ключи</b>
1. Войдите в личный кабинет Tilda
2. Настройки сайта → API
3. Или прямая ссылка: https://tilda.cc/identity/apikeys/
4. Создайте новый API ключ

<b>Шаг 2: Скопируйте ключи</b>
Вам будут выданы 2 ключа:
• Public Key (публичный)
• Secret Key (секретный)

Скопируйте оба ключа

<b>Шаг 3: Данные для подключения</b>
• Public Key: ваш_public_key
• Secret Key: ваш_secret_key

<b>📝 Примечания:</b>
• Требуется платный тариф Personal или выше
• API позволяет получать данные проекта
• Ключи действуют неограниченно
• Можно создать несколько ключей

<b>📋 Доступные функции через API:</b>
• Получение списка проектов
• Получение списка страниц
• Экспорт страниц
• Получение информации о проекте

<b>🔗 Документация:</b>
https://help-ru.tilda.cc/api
""",
        'test_endpoint': '/v1/getprojectslist'
    }
}


def get_cms_list():
    """Получить список всех CMS для меню"""
    return [
        {'id': 'wordpress', 'name': f"{info['emoji']} {info['name']}"} 
        for cms_id, info in SUPPORTED_CMS.items()
    ]


def get_cms_info(cms_id):
    """Получить информацию о CMS"""
    return SUPPORTED_CMS.get(cms_id)


def get_cms_instruction(cms_id):
    """Получить инструкцию подключения CMS"""
    cms = SUPPORTED_CMS.get(cms_id)
    return cms['instruction'] if cms else None
